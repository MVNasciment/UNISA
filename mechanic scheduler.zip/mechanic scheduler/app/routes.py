from flask import render_template, request, redirect, url_for
from app import app

# Dados temporários
appointments = []

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        data = request.form
        appointments.append(data)
        return redirect(url_for("confirm"))
    return render_template("index.html")

@app.route("/confirm", methods=["GET", "POST"])
def confirm():
    if request.method == "POST":
        action = request.form.get("action")
        if action == "edit":
            return redirect(url_for("index"))
        return "Agendamento salvo com sucesso!"
    return render_template("confirm.html", appointment=appointments[-1])
@app.route("/new", methods=["GET"])
def new():
    return redirect(url_for("index"))

